.. _release-notes:

Release notes
=============

The |version| release of |project| supports Python 3.7, 3.8, 3.9, 3.10 and
Django 3.1, 3.2, 4.0, and 4.1.
